# Lab 2: Automatic Emergency Braking

## YouTube video link
[FILL ME IN](https://tinyurl.com/22mts2ax)